#ifndef __DEVICE_MOUSE_H
#define __DEVICE_MOUSE_H
void mouse_init(void);
#endif